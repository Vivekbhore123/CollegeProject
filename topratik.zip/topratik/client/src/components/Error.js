import React from "react";

function Error() {
  return (
    <div>
      <div class="alert alert-warning" role="alert">
        <h1>Invalid credentials</h1>
      </div>
    </div>
  );
}

export default Error;
