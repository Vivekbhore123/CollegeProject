import React from "react";

import Navbar from "../components/Navbar";

function Landingscreen()
{
        return(
                <div>
                <Navbar/>
                <h1>Landing page</h1>
              </div>
        )
}

export default Landingscreen;