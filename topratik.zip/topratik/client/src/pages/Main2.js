import React from "react";

const Main2 = () => {
  return (
    <div>
      <h1>Hello Pratik</h1>
    </div>
  );
};

export default Main2;
